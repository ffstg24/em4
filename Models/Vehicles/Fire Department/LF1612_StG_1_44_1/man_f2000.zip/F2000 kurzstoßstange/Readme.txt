Modell: Stingray
Textur: waegi, Leitstelle Nord-Ost

Nutzungsbedingungen von Stingray - genutzt werden darf alles von mir unter folgenden Bedingungen:

1) Es wird erw�hnt, dass das Modell von mir erstellt worden ist
2) Du informierst mich �ber Modell�nderungen
3) Du hast Spa� mit dem Modell
4) Modellskalierungen mit dem v3o-Resizer oder Zmodeler sind erlaubt

F�r die Nutzungsbedingungen externer Autoren, musst du dich bei diesen Autoren erkundigen oder aktuelle ReadMes von diesen einsehen. 